import React from 'react'
import {FaFacebook, FaInstagram, FaLinkedin} from 'react-icons/fa'
import { NavLink } from 'react-router-dom'
const Footer = () => {
  return (
    <div style={{border:"1px solid lightgrey",height:"200px",boxShadow:" rgba(0, 0, 0, 0.3) 0px 19px 38px, rgba(0, 0, 0, 0.22) 0px 15px 12px",backgroundColor:"black",color:"white",display:"flex"}}>
     <div style={{width:"60%",display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:"20px"}}>
     <NavLink style={{color:"white",textDecoration:"none"}} to="/about"><h4>About</h4></NavLink>
     <NavLink style={{color:"white",textDecoration:"none"}} to="/contact"><h4>Contact Us</h4></NavLink>
     <h4>FAQ</h4>
     <h4>Offers</h4>
     <h4>Reffrals</h4>

     </div>
     <div style={{width:"40%" ,display:"flex",gap:"30px",textAlign:"center"}}>
      <div style={{width:"30%",margin:"auto",display:"flex",flexDirection:"row",gap:"30px",fontSize:"30px"}}>
      <FaFacebook />
      <FaInstagram />
      <FaLinkedin />
      </div>
     </div>
    </div>
  )
}

export default Footer