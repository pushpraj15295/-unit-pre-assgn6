import React from 'react'

const styled={
  // border:"1px solid lightgrey",
  width:"100%",
  height:"150px",
  paddingTop:"50px"
}
const Cart = ({item}) => {
  console.log("cart:",item)
  return (
    <div style={{border:"2px solid lightgrey",height:"500px",width:"53%",margin:"0 auto",marginTop:"50px",marginBottom:"100px",overflow:"auto"}} >
      <h1>Cart</h1>
       {item.map(el=>(
        <div key={el.id} style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",border:"1px solid lightgrey",width:"99%",padding:"20px"}}>
          <div style={styled}><img width="100px"src={el.image}/></div>
          <div style={styled}><strong>{el.title}</strong></div>
          <div style={styled}><strong>₹{el.price}</strong></div>
        </div>
       ))}
    </div>
  )
}

export default Cart