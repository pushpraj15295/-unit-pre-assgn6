import React, { useEffect, useState } from 'react'
import {useParams} from 'react-router-dom'
import {Navigate} from 'react-router-dom'
import PrivateRoute from '../PrivateRoute/PrivateRoute'
import Cart from './Cart';
const ProductShow = ({item,setItem}) => {
  const [show,setShow] = useState({});
  
  const params = useParams();
  useEffect(()=>{
    fetch(`https://fakestoreapi.com/products/${params.id}`)
    .then((r)=>r.json())
    .then((d)=>setShow(d))
  },[])
  const handleData=()=>{

    setItem([...item,show])
    // console.log("item:",item)
  }
  
  return (
    <div>
      <strong>{show.title} Details</strong>
      <br/><br/>
      <div style={{border:"1px solid lightgrey",width:"50%",margin:"auto",display:"flex"}}>
       <div style={{width:"40%"}}>
        <img width="100px" src={show.image}/>
       </div>
       <div style={{width:"100%"}}>
        <h3>{show.title}</h3>
        <h6 style={{width:"35%",fontSize:"12px"}}>Price:₹{show.price}</h6>
         <button style={{width:"70px",height:"30px",border:"1px solid tomato",backgroundColor:"tomato",color:"white",borderRadius:"3px",cursor:"pointer"}}onClick={handleData}>Buy Now</button>
       </div>
      </div>
      <div style={{border:"1px solid lightgrey",width:"50%",margin:"auto",display:"flex",marginTop:"2px",padding:"20px"}}><strong>Description:</strong>{show.description}</div>
      {/* <div ><Cart data={item}/></div> */}
    </div>
  )
}

export default ProductShow