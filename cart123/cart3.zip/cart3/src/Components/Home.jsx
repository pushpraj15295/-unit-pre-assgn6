import React from 'react'
import welcome from './welcome.svg'
import 'swiper/css';
import { Swiper, SwiperSlide } from 'swiper/react';
import nord from "./slider/nord.jpg"
import boat from './slider/boat.jpg'
import offer from './slider/offer.jpg'
const Home = () => {
  return (
    <div style={{border:"1px solid lightgrey",marginTop:"60px",paddingTop:"12px",marginBottom:"60px",height:"520px"}}>
     <img style={{width:"200px"}} src={welcome} />
     <Swiper
      spaceBetween={50}
      slidesPerView={1}
      style={{
        marginTop:"20px",
        border:"1px solid lightgrey",
        height:"300px",
      }}
      onSlideChange={() => console.log('slide change')}
      onSwiper={(swiper) => console.log(swiper)}
    >
      <SwiperSlide><img width="100%" src={nord} /></SwiperSlide>
      <SwiperSlide><img width="100%" src={boat}/></SwiperSlide>
      <SwiperSlide><img width="100%" src={offer}/></SwiperSlide>
      ...
    </Swiper>
    </div>
  )
}

export default Home