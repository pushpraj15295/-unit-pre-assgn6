import './App.css';
import Navbar from './Components/Navbar';
import {Routes,Route} from 'react-router-dom'
import Home from './Components/Home'
// import Electronics from './Components/Electronics'
// import Clothing from './Components/Clothing'
import Products from './Components/Products';
import ProductShow from './Components/ProductShow';
import Cart from './Components/Cart';
import Footer from './Components/Footer';
import About from './Components/About';
import Contact from './Components/Contact';
function App() {
  return (
    <div className="App">
      <Navbar />
      <Routes>
       <Route path="/" element={<Home />} />
       <Route path="/products" element={<Products />} />
       <Route path="/products/:id" element={<ProductShow />} />
       <Route path="/cart" element={<Cart />} />
       <Route path="/about" element={<About />} />
       <Route path="/contact" element={<Contact />}/>
       {(<Route/>) ? <Route path="/" />:alert("not found")}
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
