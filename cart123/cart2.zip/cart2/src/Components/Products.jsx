import React, { useEffect, useState } from 'react'
import {Link} from 'react-router-dom'
const styles={
    border:"1px solid lightgrey",
    fontSize:"12px",
    fontWeight:"650",
    display:"flex",
    flexDirection:"column",
    textAlign:"center",
    width:"80%",
    cursor:"pointer",
    padding:"10px",
    marginBottom:"10px"
    ,boxShadow:" rgba(0, 0, 0, 0.3) 0px 19px 38px, rgba(0, 0, 0, 0.22) 0px 15px 12px"
}
const Products = () => {
   const [data,setData]  = useState([])
    useEffect(()=> {
        fetch(`https://fakestoreapi.com/products`)
        .then((r)=>r.json())
        .then((r)=>setData(r))
    },[])
    console.log(data)
  return (
    <div>
    <strong>Products</strong>
    <br/><br/>
    <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:"20px",width:"80%",margin:"auto"}}>
    {data.map((item)=>
       <div style={styles} key={item.id}>
         <img style={{width:"99%",height:"140px"}} src={item.image} />
         <Link to={`/products/${item.id}`}>{item.title}</Link>
       </div>
    )}
    </div>
    </div>
  )
}

export default Products