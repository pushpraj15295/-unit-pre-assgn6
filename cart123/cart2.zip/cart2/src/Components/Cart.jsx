import React from 'react'

const Cart = () => {
  return (
    <div>
        <strong>COMING SOON!!!!</strong>
    </div>
  )
}

export default Cart