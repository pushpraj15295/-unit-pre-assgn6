import React from 'react'
import logo1 from './contact.svg'
const Contact = () => {
  return (
    <div style={{border:"1px solid lightgrey",height:"518px",marginTop:"60px",marginBottom:"30px", display:"flex",boxShadow:" rgba(0, 0, 0, 0.3) 0px 19px 38px, rgba(0, 0, 0, 0.22) 0px 15px 12px"}}>
    <img style={{
       width:"40%",
       height:"400px",
       marginTop:"50px",
     float:"left",
   //   marginTop:"80px",
   //   padding:"100px"
    }}  src={logo1} alt="404" />
    <div style={{padding:"90px"}}>
     <h1>Contact Us</h1>
     <input type="text" placeholder="Enter your email..." style={{width:"450px",border:"1px solid lightgrey",height:"30px",color:"red",paddingLeft:"60px"}} />
     <br/><br/>
     <input type="text" placeholder="Enter your query..." style={{border:"1px solid lightgrey",height:"90px",width:"450px",paddingLeft:"60px",overflow:"auto"}} />
    </div>
   </div>
  )
}

export default Contact