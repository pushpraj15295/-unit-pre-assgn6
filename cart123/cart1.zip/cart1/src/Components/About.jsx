import React from 'react'
import logo from './Aboutlogo.svg'
const About = () => {
  return (
    <div style={{border:"1px solid lightgrey",height:"518px",marginTop:"60px",boxShadow:" rgba(0, 0, 0, 0.3) 0px 19px 38px, rgba(0, 0, 0, 0.22) 0px 15px 12px",marginBottom:"30px", display:"flex"}}>
     <img style={{
        width:"40%",
        height:"400px",
        marginTop:"50px",
      float:"left",
    //   marginTop:"80px",
    //   padding:"100px"
     }}  src={logo} alt="404" />
     <div style={{padding:"90px"}}>
      <h1>About Us</h1>
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
     </div>
    </div>
  )
}

export default About